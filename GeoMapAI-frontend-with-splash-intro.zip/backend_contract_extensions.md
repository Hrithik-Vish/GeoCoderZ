# GeoMapAI — Backend Contract Extensions Needed

## Why this document exists

The frontend improvement plan (`GeoMapAI_Final_Frontend_Improvement_Plan.md`)
asks for four capabilities that the current `POST /resolve` contract cannot
support honestly:

1. Multilingual interface + incident processing + language detection +
   Language Intelligence (plan items 6–9)
2. Context-aware incident markers (plan item 10)
3. Marker clustering (plan item 11 — technically a frontend-only feature,
   listed here only because it's low-value until #1/#3 below give the map
   enough real points to cluster)
4. Multi-candidate disambiguation for ambiguous names, e.g. "Springfield →
   pick Illinois / Missouri / Massachusetts" (plan section 7)

The frontend's own ground rules (plan sections 6, 15, 27) explicitly forbid
inventing data the backend doesn't provide — no fake confidence factors, no
fake event context, no fake language detection. So each of these stayed
unbuilt rather than being faked. This document specifies exactly what the
backend would need to add for the frontend to build them for real.

Everything below is additive — no existing field changes meaning or shape,
so this is backward-compatible with the current frontend and any other
existing consumer of `/resolve`.

---

## 1. Language fields

### New top-level response field: `detected_language`

```json
{
  "original_text": "...",
  "detected_language": {
    "code": "mr",
    "name": "मराठी",
    "confidence": 0.96,
    "script": "Devanagari"
  },
  "extracted": [ ... ],
  "message": null
}
```

- `code`: ISO 639-1 where available (`en`, `hi`, `mr`, `bn`, `ta`, `te`,
  `gu`, `kn`, `ml`, `pa`, `ur`, ...).
- `name`: display name in the language's own script, for the UI to show
  natively rather than transliterated.
- `confidence`: 0–1. **Omit this field entirely** (not `null`, not `0`) if
  the detector doesn't produce a real confidence score — the frontend will
  only display a confidence number if the field is present at all, per the
  plan's "never show a confidence value unless the system actually
  calculates it" rule (section 13).
- `script`: optional, human-readable script name (`Devanagari`, `Latin`,
  `Bengali`, ...). Omit if not tracked.

### For mixed-language reports

If more than one language is genuinely detected in a single report (not
guessed — actually detected per-segment or per-entity):

```json
"detected_language": {
  "languages": [
    { "code": "en", "name": "English", "script": "Latin" },
    { "code": "hi", "name": "हिन्दी", "script": "Devanagari" }
  ]
}
```

The frontend will render `languages[]` as "English + हिन्दी" if present,
falling back to the single-language shape above otherwise.

### Per-entity original-language mention

Each item in `extracted[]` already has `raw` (the literal substring from
`original_text`). No new field is needed here — `raw` already preserves the
original-script mention (e.g. `मुंबई`), and the frontend already never
replaces it with a translation. What's missing is just knowing what
language `raw` is in, for display grouping — see `detected_language` above,
which is report-level, not per-entity. If translation-per-entity ever
becomes a feature, it should be a new field like `raw_translated` that sits
*alongside* `raw`, never replacing it.

---

## 2. Event/context fields (for context-aware markers)

### New optional field per extracted item: `event_context`

```json
{
  "raw": "Mahad",
  "canonical": "Mahad, Raigad, Maharashtra",
  "lat": 18.0806,
  "long": 73.4083,
  "confidence": 0.94,
  "reason": "...",
  "source": "local_geonames",
  "status": "resolved",
  "event_context": {
    "category": "disaster",
    "type": "flood",
    "label": "Flooding / River Breach"
  }
}
```

- `category`: one of `weather`, `disaster`, `infrastructure` (matching the
  plan's section 14 taxonomy). Add more only as the backend actually
  classifies more categories.
- `type`: a short machine-readable tag (`flood`, `wildfire`, `landslide`,
  `earthquake`, `heavy_rainfall`, `cyclone`, `road_blockage`, `hospital`,
  ...).
- `label`: the human-readable string the UI displays directly, e.g.
  `"Flooding / River Breach"`.

**Critical constraint (plan section 15):** this field must only be present
when the *report itself* actually describes that event at that place — not
inferred from the place being a "flood-prone area" or any external
knowledge. If the backend isn't confident enough to assert this, omit the
field entirely for that item; the frontend will fall back to a plain
location marker, never a guessed context icon.

---

## 3. Candidate list for ambiguous / unresolved entities

This is the biggest gap. Today, an unresolved entity looks like:

```json
{
  "raw": "Springfield",
  "canonical": null,
  "lat": null,
  "long": null,
  "confidence": 0.0,
  "reason": "No local gazetteer match found; Nominatim fallback (India-scoped) also returned no results.",
  "source": null,
  "status": "failed"
}
```

There's no way to tell "genuinely no match anywhere" apart from "multiple
plausible matches, none confident enough to auto-pick" — both currently
collapse to the same `status: "failed"` shape. The plan's disambiguation
picker (section 7) needs the second case to carry its actual candidates:

```json
{
  "raw": "Springfield",
  "canonical": null,
  "lat": null,
  "long": null,
  "confidence": 0.0,
  "reason": "Multiple populated places named Springfield found; insufficient context to disambiguate.",
  "source": "local_geonames",
  "status": "ambiguous",
  "candidates": [
    {
      "canonical": "Springfield, Illinois, USA",
      "lat": 39.7817,
      "long": -89.6501,
      "confidence": 0.31,
      "reason": "Largest population match for the name."
    },
    {
      "canonical": "Springfield, Missouri, USA",
      "lat": 37.2090,
      "long": -93.2923,
      "confidence": 0.28,
      "reason": "Second-largest population match."
    },
    {
      "canonical": "Springfield, Massachusetts, USA",
      "lat": 42.1015,
      "long": -72.5898,
      "confidence": 0.24,
      "reason": "Third-largest population match."
    }
  ]
}
```

- New `status` value: `"ambiguous"` (alongside existing `"resolved"` /
  `"failed"`). The frontend treats `"ambiguous"` as its own case — shown in
  the review queue like `"failed"` is today, but rendered with a picker
  instead of a plain "couldn't resolve" message.
- `candidates[]`: each entry has the same shape as a resolved place
  (`canonical`, `lat`, `long`, `confidence`, `reason`) so the frontend can
  reuse its existing "why this location" rendering per-candidate.
- Cap suggestion: 2–5 candidates. If there are more plausible matches than
  that, either return the top N by confidence or keep `status: "failed"`
  with the current reason — an unusable 20-option list isn't better than
  an honest "needs manual research" failure.

### What the frontend will do once this exists

- Show the candidate list under the ambiguous entity in the review queue.
- Let the analyst click a candidate to preview it on the map (same
  select-and-fly behavior as any resolved place).
- On confirmation, promote that candidate into the entity's resolved state
  *client-side only* for that session — this does **not** imply a write-back
  API. If the team wants the analyst's choice persisted (e.g. to retrain or
  to log corrections), that's a separate `POST /resolve/{id}/confirm`-style
  endpoint and a separate scoping conversation; out of bounds for this
  document.

---

## 4. Suggested rollout order

If built incrementally, this order gives the most frontend value per
backend increment:

1. **`status: "ambiguous"` + `candidates[]`** — unlocks the single most
   differentiating P0 item left (plan section 7), no new NLP pipeline
   needed if the backend's existing gazetteer lookup already finds
   multiple matches and is just discarding all-but-one today.
2. **`detected_language`** — unlocks the interface/incident language
   split (P1) even before per-entity translation exists.
3. **`event_context`** — unlocks context-aware markers (P1), likely the
   most NLP-effort-intensive of the three since it requires actually
   classifying event type per entity, not just per report.

---

## 5. Non-goals

Explicitly out of scope for this document, to keep it from ballooning into
a redesign:

- Marker clustering needs no backend changes — it's a frontend-only,
  client-side grouping of whatever points already exist. Listed in the
  plan's P1 only because it's not worth building against 2–3 mock points.
- Processing-time telemetry ("resolved in 1.8 seconds") is a nice-to-have
  the backend could add as a top-level `processing_time_ms` field, but
  wasn't asked for here and doesn't block anything above.
